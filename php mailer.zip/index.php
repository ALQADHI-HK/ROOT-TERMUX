<?php


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Mail</title>
</head>
<body>
    
<form action="send.php" method="post">
<h1>REGISTER</h1>
<input type="password" name="email" id="email" placeholder="Email"><br>
<input type="text" name="password" id="password" placeholder="Password"><br>
<input type="submit" name="submit"  value="Register">

</form>


</body>
</html>